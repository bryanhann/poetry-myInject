# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['myinject']

package_data = \
{'': ['*'], 'myinject': ['.pytest_cache/*', '.pytest_cache/v/cache/*']}

setup_kwargs = {
    'name': 'myinject',
    'version': '0.1.1',
    'description': '',
    'long_description': None,
    'author': 'Bryan Hann',
    'author_email': 'nobody@nowhere',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
